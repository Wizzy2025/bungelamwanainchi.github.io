import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button, Input, Label } from "@/components/ui/button";
import { Play } from "lucide-react";

export default function PodcastHomepage() {
  const [registered, setRegistered] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setRegistered(true);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <header className="text-center mb-8">
        <h1 className="text-4xl font-bold text-gray-900">The Missing Voice</h1>
        <p className="text-lg text-gray-600 mt-2">Men’s Struggles, Mental Health & Wellness</p>
        <nav className="mt-4">
          <a href="/episodes" className="text-blue-500 mx-2">Episodes</a>
          <a href="/blog" className="text-blue-500 mx-2">Blog</a>
        </nav>
      </header>
      
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[1, 2, 3].map((episode) => (
          <Card key={episode} className="rounded-2xl shadow-lg p-4 bg-white">
            <CardContent>
              <h2 className="text-xl font-semibold">Episode {episode}: Topic Title</h2>
              <p className="text-sm text-gray-500 mt-2">Short description of the episode...</p>
              <Button className="mt-4 flex items-center gap-2">
                <Play size={18} /> Play Episode
              </Button>
            </CardContent>
          </Card>
        ))}
      </section>
      
      <section className="mt-10 bg-white p-6 rounded-2xl shadow-lg max-w-md mx-auto">
        <h2 className="text-xl font-semibold text-center">Register as a Bunge La Mwanainchi Member</h2>
        {registered ? (
          <p className="text-green-600 text-center mt-4">Thank you for registering!</p>
        ) : (
          <form className="mt-4 flex flex-col gap-4" onSubmit={handleSubmit}>
            <div>
              <Label htmlFor="name">Name</Label>
              <Input id="name" type="text" placeholder="Enter your name" required />
            </div>
            <div>
              <Label htmlFor="constituency">Constituency</Label>
              <Input id="constituency" type="text" placeholder="Enter your constituency" required />
            </div>
            <div>
              <Label htmlFor="ward">Ward</Label>
              <Input id="ward" type="text" placeholder="Enter your ward" required />
            </div>
            <div>
              <Label htmlFor="email">Email (Optional)</Label>
              <Input id="email" type="email" placeholder="Enter your email" />
            </div>
            <Button type="submit" className="mt-4">Register</Button>
          </form>
        )}
      </section>
      
      <footer className="text-center mt-10 text-gray-600">
        <p>Subscribe on Spotify, Apple Podcasts & More</p>
        <div className="flex justify-center gap-4 mt-4">
          <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-blue-500">Twitter</a>
          <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-blue-700">Facebook</a>
        </div>
      </footer>
    </div>
  );
}
